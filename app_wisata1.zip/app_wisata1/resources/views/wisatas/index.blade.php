@extends('wisatas.layout')
@section('content')
<a href="{{ route('wisatas.create') }}"><button class="btn btn-primary">ADD NEW</button></a><br>
<table class="table table-border bordered-dark table-hover table-stripped"><br>
    <tr class="table table-dark text-center">
       <th>ID</th>
       <th>Image</th>
       <th>Nama</th>
       <th>Kota</th>
       <th>Harga Tiket</th>
       <th>Action</th>
    </tr>

    @foreach ($wisatas as $wisata )
        <tr>
            <td class="text-center">{{ $wisata->id }}</td>
            <td><img src="{{ Storage::url('public/images/' . $wisata->image) }}" alt=""
                style="width: 150px;"></td>
            <td class="text-center">{{ $wisata->nama }}</td>
            <td class="text-center">{{ $wisata->kota }}</td>
            <td class="text-center">{{ $wisata->harga_tiket }}</td>
            <td class="text-center">
                <a href="{{ route('wisatas.show', $wisata->id) }}"><button class="btn btn-success">SHOW</button></a>
                <a href="{{ route('wisatas.edit', $wisata->id) }}"><button class="btn btn-warning">EDIT</button></a>
                <form action="{{ route('wisatas.destroy', $wisata->id) }}" method="post" style="display: inline;"
                    onclick="return confirm('Are You Sure?')">
                @csrf
                @method('DELETE')
                <button  class="btn btn-danger">DELETE</button>
                </form>
            </td>
        </tr>
    @endforeach
</table>
{{ $wisatas->links() }}
@endsection

