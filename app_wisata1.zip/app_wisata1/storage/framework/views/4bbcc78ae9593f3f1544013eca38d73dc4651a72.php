<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('wisatas.store')); ?>" method="post" enctype="multipart/form-data" class="form">
    <?php echo csrf_field(); ?>
    <label for="">Nama</label><br>
    <input type="text" name="nama" id="" class="form-control"><br>
    <label for="">Kota</label><br>
    <input type="text" name="kota" id="" class="form-control"><br>
    <label for="">Harga Tiket</label><br>
    <input type="text" name="harga_tiket" id="" class="form-control"><br>
    <label for="">Upload Image</label><br>
    <input type="file" name="image" id="" class="form-control"><br><br>
    <input type="submit" value="SAVE" class="btn btn-success"><br>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata1/resources/views/wisatas/create.blade.php ENDPATH**/ ?>