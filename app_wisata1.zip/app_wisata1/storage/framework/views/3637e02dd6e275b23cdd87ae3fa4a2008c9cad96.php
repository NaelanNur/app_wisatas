<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('wisatas.update', $wisata->id)); ?>" method="post" enctype="multipart/form-data" class="form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="">Nama</label><br>
    <input type="text" name="nama" id="" value="<?php echo e($wisata->nama); ?>" class="form-control"><br>
    <label for="">Kota</label><br>
    <input type="text" name="kota" id="" value="<?php echo e($wisata->kota); ?>" class="form-control"><br>
    <label for="">Harga Tiket</label><br>
    <input type="text" name="harga_tiket" id="" value="<?php echo e($wisata->harga_tiket); ?>" class="form-control"><br>
    <label for="">Upload Image</label><br>
    <input type="file" name="image" id="" value="<?php echo e($wisata->image); ?>" class="form-control"><br><br>
    <input type="submit" value="SAVE" class="btn btn-success"><br>
</form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app_wisata1/resources/views/wisatas/edit.blade.php ENDPATH**/ ?>