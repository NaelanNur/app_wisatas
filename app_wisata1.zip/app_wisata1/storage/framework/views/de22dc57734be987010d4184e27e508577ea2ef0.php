<?php $__env->startSection('content'); ?>
<p>Image :<h3><img src="<?php echo e(Storage::url('public/images/' . $wisata->image)); ?>" alt=""
    style="width: 150px;"></h3></p>
<p>Nama : <h3><?php echo e($wisata->nama); ?> </h3></p>
<p>Kota : <h3><?php echo e($wisata->kota); ?> </h3></p>
<p>HTM : <h3><?php echo e($wisata->harga_tiket); ?> </h3></p>
<a href="<?php echo e(route('wisatas.index')); ?>"><button class="btn btn-secondary">BACK</button></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app_wisata1/resources/views/wisatas/show.blade.php ENDPATH**/ ?>